#include "annotimg.h"
#include <QDebug>

QStringList AnnotImg::objectsClasses=QStringList();


AnnotImg::AnnotImg(){

    this->loc=QString("");
    this->width=0;
    this->height=0;
    this->color_ch=0;


}

AnnotImg::AnnotImg(const QString loc, const int width, const int height, const int color_ch)
{

    this->loc=loc;
    this->width=width;
    this->height=height;
    this->color_ch=color_ch;

    loadImg();
}


AnnotImg::AnnotImg(QImage img, QString objName){
    this->img=img;

    addObject(objName,QRectF(img.rect()));
}



AnnotImg::AnnotImg(const AnnotImg& a){
    this->loc=a.getLoc();
    this->width=a.getWidth();
    this->height=a.getHeight();
    this->color_ch=a.getColorCh();

    this->img=QImage(a.getImageB());
}


AnnotImg::~AnnotImg(){

}


void AnnotImg::addObject(const QString name, const QRectF rect){
    ///if class not found
    if(!objectsClasses.contains(name)){
        objectsClasses.push_back(name);
    }

    localObjects.insert(localObjects.begin(),name,rect);
}




bool AnnotImg::loadImg(){
    QImage actImage;
    if(!actImage.load(loc)){
        qDebug()<<QString("IMG LOAD ERROR: %1!").arg(loc);
        return false;
    }
    else{
        this->img=QImage(actImage);
        return true;
    }

}

