#include "classifgraphicsview.h"
#include "ui_classifgraphicsview.h"

#include <QMouseEvent>

ClassifGraphicsView::ClassifGraphicsView(QWidget *parent) :
    QGraphicsView(parent),
    ui(new Ui::ClassifGraphicsView)
{
    ui->setupUi(this);
}

ClassifGraphicsView::~ClassifGraphicsView()
{
    delete ui;
}


void ClassifGraphicsView::mousePressEvent(QMouseEvent * e)
{
    emit mouseClicked(e->pos());
}
