#include "classifmainwindow.h"
#include "ui_classifmainwindow.h"

#include <QFileDialog>

#include <QDebug>
#include <QMessageBox>


QDir ClassifMainWindow::vocHome;

ClassifMainWindow::ClassifMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ClassifMainWindow)
{
    ui->setupUi(this);


    annotFilter << "*.txt";
    imgFilter << "*.png";
    imgSetsFilter << "*.txt";

    progressDialog=0;
    watcher=0;

    actImg=annotedImages.end();



    scene=new QGraphicsScene(ui->picPrew_view);
    ui->picPrew_view->setScene(scene);
    aktPixmap=0;


    isInEditState=false;
    editId=0;


    QObject::connect(ui->picPrew_view, SIGNAL(mouseClicked(QPoint)),this,SLOT(on_picPrew_view_customContextMenuRequested(QPoint)));


    trainer=new ClassifDicTrainer();
    //trainer->show();

    testSet=new ClassifTestSet();
    //testSet->show();

}

ClassifMainWindow::~ClassifMainWindow()
{
    delete ui;

    if(progressDialog!=0){
        delete progressDialog;
        progressDialog=0;
    }


    for(QMap<QString,AnnotImg*>::iterator iter=annotedImages.begin();iter!=annotedImages.end();++iter){
        AnnotImg* tmp=iter.value();
        //annotedImages.remove(iter.key());
        delete (tmp);
        tmp=0;

    }
}




void ClassifMainWindow::on_vocHOme_button_clicked()
{
    //QString patch=QFileDialog::getExistingDirectory(this, tr("Choose the VOC home folder"), QDir::currentPath(),QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);
    QString patch=QFileDialog::getExistingDirectory(this, tr("Choose the VOC home folder"), QString("./VOC2006") ,QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);

    if(!patch.isNull() && !patch.isEmpty()){
         vocHome.setPath(patch);
    }

    ui->vocHOme_line->setText(patch);

    doPharseHomeDir();

}


bool ClassifMainWindow::doPharseHomeDir(){
    QStringList filters;
    QStringList fileList=vocHome.entryList(filters,QDir::Dirs | QDir::NoDotAndDotDot);

    qDebug()<<fileList;
    if(!( fileList.contains("Annotations") && fileList.contains("ImageSets") && fileList.contains("PNGImages") ) ){
        QMessageBox::critical(this, tr("Error!"), tr("Not a Valid VOC train set! Missing dir! Aborting..."), QMessageBox::Ok);
        return false;
    }
    else{
        //set base dirs
        annotations=QDir(vocHome.absoluteFilePath("Annotations"));
        imageSets=QDir(vocHome.absoluteFilePath("ImageSets"));
        pngImages=QDir(vocHome.absoluteFilePath("PNGImages"));

        //get all file
        QStringList tmp_list=annotations.entryList(annotFilter,QDir::Files);
        for(QStringList::iterator iter=tmp_list.begin();iter!=tmp_list.end();++iter){
            annotList.append(annotations.absoluteFilePath((*iter)));
        }

        tmp_list=imageSets.entryList(imgSetsFilter,QDir::Files);
        for(QStringList::iterator iter=tmp_list.begin();iter!=tmp_list.end();++iter){
            imgSetList.append(imageSets.absoluteFilePath((*iter)));
        }

        tmp_list=pngImages.entryList(imgFilter,QDir::Files);
        for(QStringList::iterator iter=tmp_list.begin();iter!=tmp_list.end();++iter){
            imgList.append(pngImages.absoluteFilePath((*iter)));
        }


        progressDialog=new QProgressDialog(tr("Processing VOC HOME DIR..."),tr("Abort..."),0,100,this);
        progressDialog->show();

        watcher=new QFutureWatcher<AnnotImg*>(this);

        QObject::connect(watcher, SIGNAL(resultReadyAt(int)), this, SLOT(onAnnotPharsed(int)));
        QObject::connect(watcher, SIGNAL(finished()), this, SLOT(onAnnotPharsingFinished()));

        QObject::connect(watcher,SIGNAL(progressValueChanged(int)),progressDialog,SLOT(setValue(int)));
        QObject::connect(progressDialog,SIGNAL(canceled()),watcher,SLOT(cancel()));

        QObject::connect(watcher, SIGNAL(progressRangeChanged(int, int)), progressDialog, SLOT(setRange(int,int)));
        QObject::connect(watcher, SIGNAL(progressValueChanged(int)), progressDialog, SLOT(setValue(int)));
        QObject::connect(watcher, SIGNAL(finished()), progressDialog, SLOT(accept()));



        watcher->setFuture(QtConcurrent::mapped(annotList, doPharseAnnot));





        return true;
    }
}


void ClassifMainWindow::onAnnotPharsed(int num){
    //qDebug()<<"IN";
    AnnotImg* tmp=watcher->resultAt(num);
    if(tmp!=0){
        annotedImages[tmp->getLoc()]=tmp;
    }

}


void ClassifMainWindow::onAnnotPharsingFinished(){
    qDebug()<<"END";
    ui->className_combo->clear();
    ui->className_combo->addItem(QString("ALL"));
    ui->className_combo->addItems(AnnotImg::objectsClasses);

    ui->input_list->clear();
    for(QMap<QString,AnnotImg*>::iterator iter=annotedImages.begin();iter!=annotedImages.end();++iter){
        ui->input_list->addItem(new QListWidgetItem(iter.value()->getLoc()));
    }


    QObject::disconnect(watcher, SIGNAL(resultReadyAt(int)), this, SLOT(onAnnotPharsed(int)));
    QObject::disconnect(watcher, SIGNAL(finished()), this, SLOT(onAnnotPharsingFinished()));

    QObject::disconnect(watcher,SIGNAL(progressValueChanged(int)),progressDialog,SLOT(setValue(int)));
    QObject::disconnect(progressDialog,SIGNAL(canceled()),watcher,SLOT(cancel()));

    QObject::disconnect(watcher, SIGNAL(progressRangeChanged(int, int)), progressDialog, SLOT(setRange(int,int)));
    QObject::disconnect(watcher, SIGNAL(progressValueChanged(int)), progressDialog, SLOT(setValue(int)));
    QObject::disconnect(watcher, SIGNAL(finished()), progressDialog, SLOT(accept()));


    delete progressDialog;
    progressDialog=0;
    delete watcher;
    watcher=0;
}



AnnotImg* doPharseAnnot(const QString& in){
    QDir dir=ClassifMainWindow::vocHome;
    dir.cdUp();

    QFile file(in);

    /*QString filename;
    int w=0, h=0, l=0;
    int numObj=0;
    QStringList obj;*/

    AnnotImg* ret=0;


    if(file.open(QFile::ReadOnly | QFile::Text)){
        QTextStream in(&file);

        while(!in.atEnd()){
            QString line=in.readLine();

            //filename
            if(line.indexOf("Image filename : ")!=-1){
                line.replace(QString("Image filename : "),QString(""));
                line.replace(QString("\""),QString(""));


                ret=new AnnotImg(QString("%1/%2").arg(dir.absolutePath()).arg(line));
            }

            /*//size
            if(line.indexOf("Image size (X x Y x C) : ")!=-1){
                line.replace(QString("Image size (X x Y x C) : "),QString(""));
                line.replace(QString(" "),QString(""));

                QStringList out=line.split("x");
                w=out.at(0).toInt();
                h=out.at(1).toInt();
                l=out.at(2).toInt();

            }

            //filename
            if(line.indexOf("Objects with ground truth : ")!=-1){
                line.replace(QString("Objects with ground truth : "),QString(""));
                QStringList out=line.split("{");
                //QStringList out2=out.at(1).split(" ");
                numObj=out.at(0).toInt();
                line=out.at(1);
                lui->obj_comboine.replace(QStriVOC2006/ng("}"),QString(""));
                line.replace(QString(" "),QString(""));
                line.replace(QString("\"\""),QString(";"));
                line.replace(QString("\""),QString(""));
                obj=line.split(QString(";"));
                //qDebug()<<line;
                //qDebug()<<obj;

            }*/


            if(line.indexOf("Bounding box for object ")!=-1){
                line.replace(QString("Bounding box for object "),QString(""));
                line.replace(QString("(Xmin, Ymin) - (Xmax, Ymax) : "),QString(""));
                line.replace(QString(" - "),QString(""));
                line.replace(QString(")("),QString(","));
                line.replace(QString(", "),QString(","));
                line.replace(QString(" "),QString(","));
                line.replace(QString("("),QString(""));
                line.replace(QString(")"),QString(""));


                QStringList out=line.split(",");
                //qDebug()<<out.at(0).toInt();

                line=out.at(1);
                line.replace(QString("\""),QString(""));


                //qDebug()<<out.at(2);

                if(ret!=0){
                    ret->addObject(line,QRectF(out.at(2).toInt(),out.at(3).toInt(),out.at(4).toInt(),out.at(5).toInt()));
                }
            }




        }


    }
    else{
        qDebug()<<"FILE ERROR!";
    }

    return ret;
}

void ClassifMainWindow::on_input_list_currentTextChanged(const QString &currentText)
{
    if(annotedImages.find(currentText)!=annotedImages.end()){
        actImg=annotedImages.find(currentText);
        actROI=actImg.value()->getLocalObjects().end();


        showActImg();
    }
    else{
        qDebug()<<"NOT FOUND!";
    }
}


void ClassifMainWindow::showActImg(){
    if(actImg==annotedImages.end()){    return; }

    qDebug()<<"SHOW";

    if(aktPixmap!=0){
        scene->clear();
        aktPixmap=0;
    }

    aktPixmap=scene->addPixmap(QPixmap::fromImage(actImg.value()->getImage()));
    scene->setSceneRect(aktPixmap->boundingRect());
    ui->picPrew_view->fitInView(scene->sceneRect(), Qt::KeepAspectRatio);

    ui->sizeOut_lab->setText(QString("Size: %1 X %2").arg(actImg.value()->getImage().width()).arg(actImg.value()->getImage().height()));

    aktRect.clear();
    /*for(QLinkedList<QGraphicsRectItem*>::iterator iter=aktRect.begin();iter!=aktRect.end();++iter){
        //scene->removeItem(*iter);
        //if(*iter!=0)    delete (*iter);
        //(*iter)=0;
        aktRect.removeOne(*iter);
    }*/
//QMultiMap<QString, QRectF>& getLocalObjects(){  return localObjects;    }

    ui->obj_combo->clear();

    int num=0;
    for(QMultiMap<QString, QRectF>::iterator iter=actImg.value()->getLocalObjects().begin();iter!=actImg.value()->getLocalObjects().end();++iter){
        ui->obj_combo->addItem(QString("%1").arg(num));
        //qDebug()<<iter.value();
        aktRect.push_back(scene->addRect(iter.value()));

        num++;
    }
    ui->obj_combo->setCurrentIndex(0);
    on_obj_combo_currentIndexChanged(ui->obj_combo->currentText());
}

void ClassifMainWindow::on_obj_combo_currentIndexChanged(const QString &arg1)
{
    if(actImg==annotedImages.end()){    return; }

    int num=0;
    for(QMultiMap<QString, QRectF>::iterator iter=actImg.value()->getLocalObjects().begin();iter!=actImg.value()->getLocalObjects().end();++iter){
        if(num==arg1.toInt()){
            ui->objName_line->setText(iter.key());

            ui->objX1_line->setText(QString("%1").arg(iter.value().topLeft().x()));
            ui->objX2_line->setText(QString("%1").arg(iter.value().topLeft().y()));

            ui->objY1_line->setText(QString("%1").arg(iter.value().bottomRight().x()));
            ui->objY2_line->setText(QString("%1").arg(iter.value().bottomRight().x()));


            for(QLinkedList<QGraphicsRectItem*>::iterator it=aktRect.begin();it!=aktRect.end();++it){
                if(*it!=0){
                    if((*it)->rect().topLeft()==iter.value().topLeft() && (*it)->rect().bottomRight()==iter.value().bottomRight()){
                        //qDebug()<<"FOUND!";
                        actROI=(iter);
                        (*it)->setPen(QPen(Qt::red));
                    }
                    else{
                        (*it)->setPen(QPen(Qt::black));
                    }
                }
                else{
                    //qDebug()<<"FUUUK";
                }
            }

            break;
        }

        num++;
    }
    //qDebug()<<"UPDATE";



}

void ClassifMainWindow::on_className_combo_activated(const QString &arg1)
{
    qDebug()<<"ACTIVE";
    bool isSkipCheck=false;
    if(arg1.compare("ALL")==0){
        isSkipCheck=true;
    }

    ui->input_list->clear();
    for(QMap<QString,AnnotImg*>::iterator iter=annotedImages.begin();iter!=annotedImages.end();++iter){
        bool isVis=false;

        if(isSkipCheck){
            isVis=true;
        }
        else{
            for(QMultiMap<QString, QRectF>::iterator it=iter.value()->getLocalObjects().begin();it!=iter.value()->getLocalObjects().end();++it){
                if(it.key().compare(arg1)==0){
                    isVis=true;
                    break;
                }
            }
        }


        if(isVis){
            ui->input_list->addItem(new QListWidgetItem(iter.value()->getLoc()));
        }

    }

    if(ui->input_list->count()>0){
        ui->input_list->setCurrentRow(0);
    }
}

void ClassifMainWindow::on_expHome_button_clicked()
{
    //QString patch=QFileDialog::getExistingDirectory(this, tr("Choose the VOC home folder"), QDir::currentPath(),QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);
    QString patch=QFileDialog::getExistingDirectory(this, tr("Choose the EXPORT home folder"), QString("%1/%2").arg(QDir::currentPath()).arg("export") ,QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);

    if(!patch.isNull() && !patch.isEmpty()){
        expHome.setPath(patch);
    }

    ui->expHome_line->setText(patch);

}

void ClassifMainWindow::on_editP1_button_toggled(bool checked)
{
    isInEditState=checked;
    editId=1;


    ui->options_box->setDisabled(checked);
    ui->current_class_box->setDisabled(checked);
    ui->input_list_box->setDisabled(checked);

    ui->addROIToDic_button->setDisabled(checked);

    ui->objX2_line->setDisabled(checked);
    ui->objY2_line->setDisabled(checked);
    ui->editP2_button->setDisabled(checked);

    ui->obj_combo->setDisabled(checked);
    ui->objName_line->setDisabled(checked);


    //actImg actROI


}

void ClassifMainWindow::on_editP2_button_toggled(bool checked)
{
    isInEditState=checked;
    editId=2;

    ui->options_box->setDisabled(checked);
    ui->current_class_box->setDisabled(checked);
    ui->input_list_box->setDisabled(checked);

    ui->addROIToDic_button->setDisabled(checked);

    ui->objX1_line->setDisabled(checked);
    ui->objY1_line->setDisabled(checked);
    ui->editP1_button->setDisabled(checked);

    ui->obj_combo->setDisabled(checked);
    ui->objName_line->setDisabled(checked);

}


void ClassifMainWindow::on_picPrew_view_customContextMenuRequested(const QPoint &pos)
{
    qDebug()<<"SSTART";
    if(!isInEditState){ return; }

    if(actImg==annotedImages.end()){ qDebug()<<"ACTIMG FAIL!";   return; }
    if(actROI==actImg.value()->getLocalObjects().end()){ qDebug()<<"ACTROI FAIL!";   return; }

    bool isChanged=false;
    for(QMultiMap<QString, QRectF>::iterator iter=actImg.value()->getLocalObjects().begin();iter!=actImg.value()->getLocalObjects().end();++iter){

            for(QLinkedList<QGraphicsRectItem*>::iterator it=aktRect.begin();it!=aktRect.end();++it){
                if(*it!=0){
                    if((*it)->rect().topLeft()==iter.value().topLeft() && (*it)->rect().bottomRight()==iter.value().bottomRight()){
                        if(!isChanged){
                            qDebug()<<"FOUND!";
                            (*it)->setPen(QPen(Qt::black));

                            QRectF newRect;
                            if(editId==2){
                                newRect.setTopLeft(pos);
                                newRect.setBottomRight((*it)->rect().bottomRight());
                            }
                            else{
                                newRect.setTopLeft((*it)->rect().topLeft());
                                newRect.setBottomRight(pos);
                            }



                            actImg.value()->getLocalObjects().insert(actImg.value()->getLocalObjects().begin(),actROI.key(),newRect);
                            actROI=actImg.value()->getLocalObjects().begin();
                            aktRect.push_back(scene->addRect(iter.value(),QPen(Qt::red)));
                            (*it)->setRect(newRect);
                            isChanged=true;

                        }

                    }
                    else{
                        (*it)->setPen(QPen(Qt::black));
                    }
                }
                else{
                    qDebug()<<"FUUUK";
                }
            }

            break;



    }
}

void ClassifMainWindow::on_addFULLToTeszt_button_clicked()
{
    if(actImg==annotedImages.end()){    return; }

    testSet->addPicToTestSet(actImg.key(),actImg.value());
}

void ClassifMainWindow::on_addROIToDic_button_clicked()
{
    if(actImg==annotedImages.end()){ qDebug()<<"ACTIMG FAIL!";   return; }
    if(actROI==actImg.value()->getLocalObjects().end()){ qDebug()<<"ACTROI FAIL!";   return; }

    trainer->addPicsToDic(actImg.key(),actImg.value()->getImage().copy(actROI.value().toRect()),actROI.key());

}


