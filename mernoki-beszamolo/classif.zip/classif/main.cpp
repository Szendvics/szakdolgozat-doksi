#include "classifmainwindow.h"
#include <QApplication>

#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/features2d/features2d.hpp"
#include "opencv2/nonfree/nonfree.hpp"
#include "opencv2/ml/ml.hpp"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    ClassifMainWindow w;
    cv::initModule_nonfree();
    w.showMaximized();

    return a.exec();
}
