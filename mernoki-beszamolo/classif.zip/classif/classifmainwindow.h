#ifndef CLASSIFMAINWINDOW_H
#define CLASSIFMAINWINDOW_H

#include <QMainWindow>
#include <QDir>
#include <QStringList>
#include <QLinkedList>

#include <QtConcurrent>

#include <QProgressDialog>


#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QGraphicsRectItem>

#include "annotimg.h"


#include "classifdictrainer.h"
#include "classiftestset.h"

namespace Ui {
class ClassifMainWindow;
}

AnnotImg* doPharseAnnot(const QString & in);
class ClassifMainWindow : public QMainWindow
{
    Q_OBJECT

protected:
    //QDir vocHome;

    QDir annotations;
    QDir imageSets;
    QDir pngImages;


    QStringList annotFilter;
    QStringList imgFilter;
    QStringList imgSetsFilter;


    QStringList annotList;
    QStringList imgList;
    QStringList imgSetList;



    //threading
    QFuture<AnnotImg> future;
    QFutureWatcher<AnnotImg*>*watcher;

    QProgressDialog* progressDialog;

    //anoatted
    QMap<QString,AnnotImg*>annotedImages;
    QMap<QString,AnnotImg*>::iterator actImg;
    QMultiMap<QString, QRectF>::iterator actROI;

    //previre
    QGraphicsScene* scene;
    QGraphicsPixmapItem* aktPixmap;
    QLinkedList<QGraphicsRectItem*>aktRect;


    //edit
    bool isInEditState;
    int editId;

    //exp
    QDir expHome;


    //trainer
    ClassifDicTrainer* trainer;
    ClassifTestSet* testSet;



public:
    static QDir vocHome;
    explicit ClassifMainWindow(QWidget *parent = 0);
    ~ClassifMainWindow();




private slots:
    void on_vocHOme_button_clicked();
    //AnnotImg doPharseAnnot(const QString & in);

    void onAnnotPharsed(int);
    void onAnnotPharsingFinished();

    void on_input_list_currentTextChanged(const QString &currentText);

    void on_obj_combo_currentIndexChanged(const QString &arg1);

    void on_className_combo_activated(const QString &arg1);

    void on_expHome_button_clicked();

    void on_editP1_button_toggled(bool checked);

    void on_editP2_button_toggled(bool checked);



    void on_picPrew_view_customContextMenuRequested(const QPoint &pos);

    void showActImg();

    void on_addFULLToTeszt_button_clicked();

    void on_addROIToDic_button_clicked();

signals:
    void progressValueChanged(int);
    void progressTextChanged(QString);


private:
    Ui::ClassifMainWindow *ui;


    bool doPharseHomeDir();

};

#endif // CLASSIFMAINWINDOW_H
