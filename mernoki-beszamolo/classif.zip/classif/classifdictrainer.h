#ifndef CLASSIFDICTRAINER_H
#define CLASSIFDICTRAINER_H

#include <QWidget>
#include "annotimg.h"


#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QGraphicsRectItem>

#include <QLinkedList>

#include <QtConcurrent>




using namespace cv;
using namespace std;


namespace Ui {
class ClassifDicTrainer;
}


AnnotImg* doFeatures(AnnotImg *img);
AnnotImg* doSVM(AnnotImg *img);
class ClassifDicTrainer : public QWidget
{
    Q_OBJECT

protected:
    QMap<QString,AnnotImg*>trainSet;
    QMap<QString,AnnotImg*>::iterator actImg;


    //preview
    QGraphicsScene* scene;
    QGraphicsPixmapItem* aktPixmap;

    //state
    bool isInTrainingState;


    //threading
    QFuture<AnnotImg> future;
    QFutureWatcher<AnnotImg*>*watcher;


    //classes for training
    QMap<QString, int>vocHelper;



public:
    explicit ClassifDicTrainer(QWidget *parent = 0);
    ~ClassifDicTrainer();

    //training
    static Ptr<FeatureDetector>featureDetector;
    static Ptr<DescriptorExtractor>descExtractor;
    static Ptr<DescriptorMatcher> descMatcher;
    static Ptr<BOWImgDescriptorExtractor> bowExtractor;

    static QString detector;
    static QString extractor;
    static QString matcher;

    static BOWKMeansTrainer* bowTrainer;




private:
    Ui::ClassifDicTrainer *ui;

public slots:
    void addPicsToDic(QString key,QImage img, QString name);

    //desc thread
    void onDescCalced(int);
    void onDescCalcingFinished();

    //SVM
    void onSVMCalced(int);
    void onSVMCalcingFinished();


private slots:
    void on_type_combo_currentTextChanged(const QString &arg1);
    void on_NextButton_clicked();
    void on_PrevButton_clicked();



    void on_doPreview_button_clicked();

    void preProcessOneImage(cv::Mat img, Ptr<FeatureDetector>& featureDetector, Ptr<DescriptorExtractor>& descExtractor);
    void on_samples_list_currentTextChanged(const QString &currentText);

    void showImage(QImage img);
    void on_nextPics_button_clicked();
    void on_prevPics_button_clicked();
    void on_doStartComputing_button_clicked();

public:
    static bool readVocabulary(const string& filename, Mat& vocabulary){
        FileStorage fs( filename, FileStorage::READ );
        if(fs.isOpened()){
            fs["vocabulary"]>>vocabulary;

            return true;
        }
        return false;
    }

    static bool writeVocabulary( const string& filename, const Mat& vocabulary){
        FileStorage fs(filename, FileStorage::WRITE);
        if( fs.isOpened()){
            fs << "vocabulary" << vocabulary;
            return true;
        }
        return false;
    }

};

#endif // CLASSIFDICTRAINER_H
