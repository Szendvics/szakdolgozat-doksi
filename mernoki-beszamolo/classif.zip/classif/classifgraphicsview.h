#ifndef CLASSIFGRAPHICSVIEW_H
#define CLASSIFGRAPHICSVIEW_H

#include <QWidget>
#include <QGraphicsView>
namespace Ui {
class ClassifGraphicsView;
}

class ClassifGraphicsView : public QGraphicsView
{
    Q_OBJECT

public:
    explicit ClassifGraphicsView(QWidget *parent = 0);
    ~ClassifGraphicsView();

public slots:
        void mousePressEvent(QMouseEvent * e);


signals:
    void mouseClicked(QPoint);

private:
    Ui::ClassifGraphicsView *ui;
};

#endif // CLASSIFGRAPHICSVIEW_H
