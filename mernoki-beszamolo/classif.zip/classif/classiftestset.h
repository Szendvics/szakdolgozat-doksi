#ifndef CLASSIFTESTSET_H
#define CLASSIFTESTSET_H

#include <QWidget>
#include "annotimg.h"


#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QGraphicsRectItem>


#include <QDebug>

#include <QtConcurrent>

namespace Ui {
class ClassifTestSet;
}

class ClassifTestSet : public QWidget
{
    Q_OBJECT

protected:
    QMap<QString,AnnotImg*>testSet;
    QMap<QString,AnnotImg*>::iterator actImg;

    //previre
    QGraphicsScene* scene;
    QGraphicsPixmapItem* aktPixmap;
    QLinkedList<QGraphicsRectItem*>aktRect;


    //threading
    QFuture<AnnotImg> future;
    QFutureWatcher<AnnotImg*>*watcher;

public:
    explicit ClassifTestSet(QWidget *parent = 0);
    ~ClassifTestSet();



private:
    Ui::ClassifTestSet *ui;

public slots:
    void addPicToTestSet(const QString key, AnnotImg* in);

private slots:
    void on_testItems_list_currentTextChanged(const QString &currentText);
    void showActImg();
};

#endif // CLASSIFTESTSET_H
