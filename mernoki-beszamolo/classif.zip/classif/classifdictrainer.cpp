#include "classifdictrainer.h"
#include "ui_classifdictrainer.h"

#include <QMessageBox>

Ptr<FeatureDetector> ClassifDicTrainer::featureDetector;
Ptr<DescriptorExtractor> ClassifDicTrainer::descExtractor;
Ptr<DescriptorMatcher> ClassifDicTrainer::descMatcher;
Ptr<BOWImgDescriptorExtractor> ClassifDicTrainer::bowExtractor;

BOWKMeansTrainer* ClassifDicTrainer::bowTrainer=0;

QString ClassifDicTrainer::detector=QString("SIFT");
QString ClassifDicTrainer::extractor=QString("SIFT");
QString ClassifDicTrainer::matcher=QString("BruteForce");

ClassifDicTrainer::ClassifDicTrainer(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ClassifDicTrainer)
{
    ui->setupUi(this);

    actImg=trainSet.end();

    scene=new QGraphicsScene(ui->picPrew_view);
    ui->picPrew_view->setScene(scene);
    aktPixmap=0;
    isInTrainingState=false;
}

ClassifDicTrainer::~ClassifDicTrainer()
{
    delete ui;
}


void ClassifDicTrainer::addPicsToDic(QString key, QImage img, QString name){
    if(!isInTrainingState){
        trainSet.insert(trainSet.begin(),key,new AnnotImg(img,name));

        if(ui->type_combo->findText(name)==-1){
            ui->type_combo->addItem(name);
        }
        if(ui->type_combo->findText(name)==ui->type_combo->currentIndex()){
            on_type_combo_currentTextChanged(name);
        }
        else{
            ui->type_combo->setCurrentIndex(ui->type_combo->findText(name));
        }

        //ui->samples_list->addItem(new QListWidgetItem(key));


        this->show();
    }
    else{
        QMessageBox::critical(this, tr("Error!"), tr("Data insert failed! Reson:%1").arg("Trainer is currently busy!"), QMessageBox::Ok);
    }
}

void ClassifDicTrainer::on_type_combo_currentTextChanged(const QString &arg1)
{
    ui->samples_list->clear();
    for(QMap<QString,AnnotImg*>::iterator iter=trainSet.begin();iter!=trainSet.end();++iter){
        for(QMultiMap<QString, QRectF>::iterator it= (iter.value())->getLocalObjects().begin();it!=(iter.value())->getLocalObjects().end();++it){
            if(it.key().compare(arg1)==0){
                ui->samples_list->addItem(new QListWidgetItem(iter.key()));
                break;
            }
        }

    }
}

void ClassifDicTrainer::on_NextButton_clicked()
{
    if(ui->traindic_stacked->count()>=ui->traindic_stacked->currentIndex()+1){
        ui->traindic_stacked->setCurrentIndex(ui->traindic_stacked->currentIndex()+1);
    }
}

void ClassifDicTrainer::on_PrevButton_clicked()
{
    if(ui->traindic_stacked->currentIndex()>0){
        ui->traindic_stacked->setCurrentIndex(ui->traindic_stacked->currentIndex()-1);
    }
}

void ClassifDicTrainer::on_doPreview_button_clicked()
{
    if(actImg==trainSet.end()){
        if(trainSet.size()>0)
            actImg=trainSet.begin();
        else
            return;
    }

    //if(featureDetector.empty())
        featureDetector=FeatureDetector::create(ui->fetaure_combo->currentText().toStdString());

    //if(descExtractor.empty())
        descExtractor=DescriptorExtractor::create(ui->fetaureExtr_combo->currentText().toStdString());


    qDebug()<<QString("%1 - %2").arg(ui->fetaure_combo->currentText()).arg(ui->fetaureExtr_combo->currentText());

    if(featureDetector.empty()){
        QMessageBox::critical(this, tr("Error!"), tr("Error creating the FeatureDetector: %1"), QMessageBox::Ok);
    }
    else if(descExtractor.empty()){
        QMessageBox::critical(this, tr("Error!"), tr("Error creating the FeatureExtractor: %1"), QMessageBox::Ok);
    }
    else{
        //Ptr<DescriptorMatcher> descMatcher=DescriptorMatcher::create(ddmParams.matcherType);


        preProcessOneImage(AnnotImg::QImage2Mat(actImg.value()->getImage()),featureDetector,descExtractor);
    }
}


void ClassifDicTrainer::preProcessOneImage(cv::Mat img, Ptr<FeatureDetector>& featureDetector, Ptr<DescriptorExtractor>& descExtractor){

    vector<KeyPoint>keys;
    featureDetector->detect(img, keys);

    Mat out;
    drawKeypoints(img,keys,out);

    showImage(AnnotImg::Mat2QImage(out));



    Mat desc;
    descExtractor->compute(img, keys, desc);
    if(!desc.empty()){

    }


}

void ClassifDicTrainer::on_samples_list_currentTextChanged(const QString &currentText)
{
    if(trainSet.find(currentText)!=trainSet.end()){
        actImg=trainSet.find(currentText);
    }
    else{
        qDebug()<<"NOT FOUND!";
    }
}

void ClassifDicTrainer::showImage(QImage img){
    if(actImg==trainSet.end()){    return; }

   // qDebug()<<"SHOW";

    if(aktPixmap!=0){
        scene->clear();
        aktPixmap=0;
    }

    aktPixmap=scene->addPixmap(QPixmap::fromImage(img));
    scene->setSceneRect(aktPixmap->boundingRect());
    ui->picPrew_view->fitInView(scene->sceneRect(), Qt::KeepAspectRatio);

}

void ClassifDicTrainer::on_nextPics_button_clicked()
{
    if(actImg==trainSet.end()){    return; }
    actImg++;
    if(actImg==trainSet.end()){
        actImg=trainSet.begin();
    }

    on_doPreview_button_clicked();

}

void ClassifDicTrainer::on_prevPics_button_clicked()
{
    if(actImg==trainSet.begin()){    return; }
    actImg--;
    if(actImg==trainSet.begin()){
        actImg=trainSet.end()-1;
    }

    on_doPreview_button_clicked();
}

void ClassifDicTrainer::on_doStartComputing_button_clicked()
{
    isInTrainingState=true;
    ui->NextButton->setDisabled(true);
    ui->PrevButton->setDisabled(true);


     ClassifDicTrainer::detector=ui->fetaure_combo->currentText();
     ClassifDicTrainer::extractor=ui->fetaureExtr_combo->currentText();
     ClassifDicTrainer::matcher=ui->destMatcher_combo->currentText();

    //Ptr<BOWImgDescriptorExtractor>bowExtractor;

    qDebug()<<QString("%1 - %2").arg(ui->fetaure_combo->currentText()).arg(ui->fetaureExtr_combo->currentText());

  /*  if(featureDetector==0){
        QMessageBox::critical(this, tr("Error!"), tr("Error creating the FeatureDetector: %1"), QMessageBox::Ok);
    }
    else if(descExtractor==0){
        QMessageBox::critical(this, tr("Error!"), tr("Error creating the FeatureExtractor: %1"), QMessageBox::Ok);
    }
    else{
        //descMatcher=DescriptorMatcher::create(ddmParams.matcherType);
        //preProcessOneImage(AnnotImg::QImage2Mat(actImg.value()->getImage()),featureDetector,descExtractor);
            //ClassifDicTrainer::bowTrainer=0;



*/

        vocHelper.clear();
        for(QMap<QString,AnnotImg*>::iterator iter=trainSet.begin();iter!=trainSet.end();++iter){
            for(QMultiMap<QString, QRectF>::iterator it=iter.value()->getLocalObjects().begin();it!=iter.value()->getLocalObjects().end();++it){
                vocHelper[it.key()]=1;
            }
        }

        if(featureDetector.empty())
            featureDetector=FeatureDetector::create(ui->fetaure_combo->currentText().toStdString());

        if(descExtractor.empty())
            descExtractor=DescriptorExtractor::create(ui->fetaureExtr_combo->currentText().toStdString());

        if(descMatcher.empty())
            descMatcher=DescriptorMatcher::create(ClassifDicTrainer::matcher.toStdString());

        bowExtractor = new BOWImgDescriptorExtractor( descExtractor, descMatcher );

        TermCriteria terminate_criterion;
        terminate_criterion.epsilon=FLT_EPSILON;
        ClassifDicTrainer::bowTrainer= new BOWKMeansTrainer(vocHelper.size(), terminate_criterion, 3, KMEANS_PP_CENTERS);


        watcher=new QFutureWatcher<AnnotImg*>(this);

        QObject::connect(watcher, SIGNAL(resultReadyAt(int)), this, SLOT(onDescCalced(int)));
        QObject::connect(watcher, SIGNAL(finished()), this, SLOT(onDescCalcingFinished()));

        QObject::connect(watcher,SIGNAL(progressValueChanged(int)),ui->visLib_progress,SLOT(setValue(int)));
        QObject::connect(ui->abortButton,SIGNAL(clicked()),watcher,SLOT(cancel()));

        QObject::connect(watcher, SIGNAL(progressRangeChanged(int, int)), ui->visLib_progress, SLOT(setRange(int,int)));
        QObject::connect(watcher, SIGNAL(progressValueChanged(int)), ui->visLib_progress, SLOT(setValue(int)));

        watcher->setFuture(QtConcurrent::mapped(trainSet.values(), doFeatures));

  //  }

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
AnnotImg* doFeatures(AnnotImg* img){
    AnnotImg* tmp=img;
    //qDebug()<<"FEATURES DONE!";
    RNG& rng=theRNG();

    Ptr<FeatureDetector>featureDetector=FeatureDetector::create(ClassifDicTrainer::detector.toStdString());
    Ptr<DescriptorExtractor>descExtractor=DescriptorExtractor::create(ClassifDicTrainer::extractor.toStdString());


    if(featureDetector.empty()){
            QMessageBox::critical(0, QString("Error!"), QString("Error creating the FeatureDetector: %1"), QMessageBox::Ok);
    }
    else if(descExtractor.empty()){
            QMessageBox::critical(0, QString("Error!"), QString("Error creating the FeatureExtractor: %1"), QMessageBox::Ok);
    }
    else{
        Mat in=AnnotImg::QImage2Mat(img->getImage());
        featureDetector->detect(in, img->getKeys());

        descExtractor->compute(in, img->getKeys(), img->getExtMat());
        if(!img->getExtMat().empty()){
            int descCount=img->getExtMat().rows;
            int descsToExtract = static_cast<int>(0.3f * static_cast<float>(descCount));

            vector<char>usedMask(descCount, false);
            fill(usedMask.begin(), usedMask.begin()+descsToExtract, true);

            for(int i=0; i<descCount; ++i){
                int i1=rng(descCount), i2=rng(descCount);

                char tmp=usedMask[i1];

                usedMask[i1]=usedMask[i2];
                usedMask[i2]=tmp;
            }

            for(int i=0; i<descCount; ++i){
                if(usedMask[i]) //&& bowTrainerdescripotorsCount()<maxDescCount)
                    ClassifDicTrainer::bowTrainer->add(img->getExtMat().row(i));
            }

        }


    }


    return tmp;
}


void ClassifDicTrainer::onDescCalced(int num){
    static int curr=0;

    qDebug()<<"IN";
    AnnotImg* tmp=watcher->resultAt(num);


    Mat out;
    drawKeypoints(AnnotImg::QImage2Mat(tmp->getImage()),tmp->getKeys(),out);
    AnnotImg::Mat2QImage(out).save(QString("./%1.png").arg(curr));
    curr++;

}

void ClassifDicTrainer::onDescCalcingFinished(){
    Mat voc=ClassifDicTrainer::bowTrainer->cluster();

    bowExtractor->setVocabulary(voc);

    if(!writeVocabulary(string("./out.txt"), voc)){
        qDebug()<<"VOC FILE NOT BACKUPED!";
    }
    qDebug()<<"END";

    QObject::disconnect(watcher, SIGNAL(resultReadyAt(int)), this, SLOT(onDescCalced(int)));
    QObject::disconnect(watcher, SIGNAL(finished()), this, SLOT(onDescCalcingFinished()));

    QObject::disconnect(watcher,SIGNAL(progressValueChanged(int)),ui->visLib_progress,SLOT(setValue(int)));
    QObject::disconnect(watcher, SIGNAL(progressRangeChanged(int, int)), ui->visLib_progress, SLOT(setRange(int,int)));
    QObject::disconnect(watcher, SIGNAL(progressValueChanged(int)), ui->visLib_progress, SLOT(setValue(int)));


    QObject::connect(watcher, SIGNAL(resultReadyAt(int)), this, SLOT(onSVMCalced(int)));
    QObject::connect(watcher, SIGNAL(finished()), this, SLOT(onSVMCalcingFinished()));

    QObject::connect(watcher,SIGNAL(progressValueChanged(int)),ui->SVM_progress,SLOT(setValue(int)));
    QObject::connect(watcher, SIGNAL(progressRangeChanged(int, int)), ui->SVM_progress, SLOT(setRange(int,int)));
    QObject::connect(watcher, SIGNAL(progressValueChanged(int)), ui->SVM_progress, SLOT(setValue(int)));


    vector<Mat> bowImageDescriptors;
    vector<char> objectPresent;

    Mat trainData((int)trainSet.values().size(), bowExtractor->getVocabulary().rows, CV_32FC1 );
    Mat responses((int)trainSet.values().size(), 1, CV_32SC1 );


    /*for( size_t imageIdx=0; imageIdx<trainSet.size(); imageIdx++){
        // Transfer image descriptor (bag of words vector) to training data matrix
        Mat submat = trainData.row((int)imageIdx);
        if( bowImageDescriptors[imageIdx].cols!=bowExtractor->descriptorSize()){
            cout << "Error: computed bow image descriptor size " << bowImageDescriptors[imageIdx].cols
                 << " differs from vocabulary size" << bowExtractor->getVocabulary().cols << endl;
            exit(-1);
        }
        bowImageDescriptors[imageIdx].copyTo(submat);

        // Set response value
        responses.at<int>((int)imageIdx) = objectPresent[imageIdx] ? 1 : -1;
    }*/






    watcher->setFuture(QtConcurrent::mapped(trainSet.values(), doSVM));


}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
AnnotImg* doSVM(AnnotImg *img){
    CvSVM svm;


    return img;
}


void ClassifDicTrainer::onSVMCalced(int num){
    qDebug()<<"SVM";
    AnnotImg* tmp=watcher->resultAt(num);

}

void ClassifDicTrainer::onSVMCalcingFinished(){
    qDebug()<<"SVM END";
}
