#include "classiftestset.h"
#include "ui_classiftestset.h"

ClassifTestSet::ClassifTestSet(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ClassifTestSet)
{
    ui->setupUi(this);

    actImg=testSet.end();

    scene=new QGraphicsScene(ui->picPrew_view);
    ui->picPrew_view->setScene(scene);
    aktPixmap=0;
}

ClassifTestSet::~ClassifTestSet()
{
    delete ui;
}


void ClassifTestSet::addPicToTestSet(const QString key, AnnotImg *in){
    if(in!=0){
        testSet.insert(testSet.begin(),key,in);

        ui->testItems_list->addItem(new QListWidgetItem(key,ui->testItems_list));

        this->show();
    }
}

void ClassifTestSet::on_testItems_list_currentTextChanged(const QString &currentText)
{
    if(testSet.find(currentText)!=testSet.end()){
        actImg=testSet.find(currentText);

        showActImg();
    }
}

void ClassifTestSet::showActImg(){
    if(actImg==testSet.end()){    return; }

   // qDebug()<<"SHOW";

    if(aktPixmap!=0){
        scene->clear();
        aktPixmap=0;
    }

    aktPixmap=scene->addPixmap(QPixmap::fromImage(actImg.value()->getImage()));
    scene->setSceneRect(aktPixmap->boundingRect());
    ui->picPrew_view->fitInView(scene->sceneRect(), Qt::KeepAspectRatio);

    ui->sizeOut_lab->setText(QString("Size: %1 X %2").arg(actImg.value()->getImage().width()).arg(actImg.value()->getImage().height()));
}
