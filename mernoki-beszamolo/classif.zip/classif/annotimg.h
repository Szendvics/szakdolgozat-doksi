#ifndef ANNOTIMG_H
#define ANNOTIMG_H

#include <QString>
#include <QStringList>
#include <QLinkedList>
#include <QMap>
#include <QMultiMap>

#include <QImage>
#include <QRectF>

#include <QTreeWidgetItem>

#include <QDebug>


#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/features2d/features2d.hpp"
#include "opencv2/nonfree/nonfree.hpp"
#include "opencv2/ml/ml.hpp"

using namespace std;
using namespace cv;

class AnnotImg
{
private:
    QString loc;
    int width;
    int height;
    int color_ch;

    QImage img;


    //fetaure detect
    QString featureDetector;
    vector<KeyPoint>keys;

    //feature extract
    QString featureExtractor;
    Mat ext;




protected:
    QMultiMap<QString, QRectF>localObjects;


public:
    static QStringList objectsClasses;

    AnnotImg();
    AnnotImg(const QString loc, const int width=0, const int height=0, const int color_ch=0);
    AnnotImg(const AnnotImg&);
    AnnotImg(QImage img, QString objName);

    virtual ~AnnotImg();


    bool loadImg();
    void addObject(const QString name, const QRectF rect);


    QString getLoc()const{  return loc; }
    int getWidth()const{     return width;   }
    int getHeight()const{   return height;  }
    int getColorCh()const{  return color_ch;    }

    QImage& getImage(){    return img; }
    QImage getImageB()const{    return img; }


    QMultiMap<QString, QRectF>& getLocalObjects(){  return localObjects;    }

    vector<KeyPoint>& getKeys(){    return keys;    }
    Mat& getExtMat(){   return ext; }



    static QImage Mat2QImage(cv::Mat const& src)
    {
         cv::Mat temp; // make the same cv::Mat
         cvtColor(src, temp,CV_BGR2RGB); // cvtColor Makes a copt, that what i need
         QImage dest((uchar*) temp.data, temp.cols, temp.rows, temp.step, QImage::Format_RGB888);
         QImage dest2(dest);
         dest2.detach(); // enforce deep copy
         return dest2;
    }

    static cv::Mat QImage2Mat(const QImage& qimage)
    {
        cv::Mat mat = cv::Mat(qimage.height(), qimage.width(), CV_8UC4, (uchar*)qimage.bits(), qimage.bytesPerLine());
        cv::Mat mat2 = cv::Mat(mat.rows, mat.cols, CV_8UC3 );
        int from_to[] = { 0,0,  1,1,  2,2 };
        cv::mixChannels( &mat, 1, &mat2, 1, from_to, 3 );

        return mat2;
    }


};



#endif // ANNOTIMG_H
